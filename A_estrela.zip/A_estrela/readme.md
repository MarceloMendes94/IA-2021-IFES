# A estrela 
como rodar:
```
python3 A_ESTRELA.py grid.txt [0,0] [14,13]
```